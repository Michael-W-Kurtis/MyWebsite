<!--
  THIS IS A PLACEHOLDER.

  Replace the contents of this file with the real resume, in Markdown.
  Path (from the repository root):   web/content/resume.md
  Path (inside the web container):   /app/content/resume.md

  The file is bind-mounted read-only into the container, so an edit here shows
  up on the next page load. No rebuild, no restart.

  Optional: drop a PDF at web/content/resume.pdf and a "Download PDF" button
  appears on the page automatically. Filename must be exactly resume.pdf.
-->

# Jonathan Doeth

Portland, OR &middot; [jonathan.doeth@gmail.com](mailto:jonathan.doeth@gmail.com) &middot; [github.com/torvalds](https://github.com/torvalds)

Systems engineer. Ten years building services that other engineers depend on, with
a persistent side interest in taking images apart.

## Experience

### Senior Software Engineer — Northlight Systems
*2021 – present*

- Owned the ingest pipeline that moves roughly 40 TB a day into cold storage.
- Cut median deploy time from 22 minutes to under 4 by replacing a bespoke
  release script with a boring, well-tested one.
- Mentored three engineers through their first on-call rotations.

### Software Engineer — Rivergate Labs
*2017 – 2021*

- Built and ran the internal image-processing service used by four product teams.
- Migrated a monolith's session layer off sticky routing with no user-visible downtime.

### Junior Developer — Cascade Interactive
*2015 – 2017*

- Maintained a Django application serving about 60,000 monthly users.

## Skills

**Languages** — Python, Go, TypeScript, SQL
**Infrastructure** — Docker, Terraform, PostgreSQL, SQLite, nginx, AWS
**Other** — Pillow, NumPy, ffmpeg, far too much time spent on glitch art

## Education

**B.S. Computer Science** — Oregon State University, 2015

## Elsewhere

- **Pixelsort Wrapper** — a browser front end for satyarth/pixelsort.
- Occasional contributor to small open-source imaging tools.
